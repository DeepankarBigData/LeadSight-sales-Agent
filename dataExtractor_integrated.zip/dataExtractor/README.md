# NEXUS — Sales Intelligence Agent
## Setup & Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
playwright install chromium
```

### 2. Start the backend server
```bash
python server.py
# Server runs at http://localhost:5000
```

### 3. Open the UI
Open `index.html` in your browser — either double-click it, or serve it:
```bash
# Quick option:
python -m http.server 8080
# Then visit http://localhost:8080
```

### 4. Upload & Run
- Upload any `.xlsx` / `.csv` with columns: `company_name`, `website`
  (the included `companies.xlsx` works out of the box)
- Click **Run Intelligence Agent**
- Watch real-time progress as each company is crawled
- Download `sales_intelligence_output.xlsx` when done

---

## API Endpoints (server.py)

| Method | Path        | Description                              |
|--------|-------------|------------------------------------------|
| POST   | /upload     | Upload Excel file, start scraping        |
| GET    | /progress   | SSE stream of live events                |
| GET    | /status     | Current job status (JSON)                |
| GET    | /results    | Results extracted so far (JSON)          |
| GET    | /download   | Download output.xlsx                     |

## Output Columns (output.xlsx)
- Company Name
- Website
- Founded Info
- About Us
- Email
